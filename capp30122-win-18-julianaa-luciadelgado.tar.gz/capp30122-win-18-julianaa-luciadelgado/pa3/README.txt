CS 122: Course Search Engine: backend

ui: Django interface
  courses.py: you will modify this file.

  **** Do not modify these files ****
    course-information.sqlite3
    db.sqlite3
    manage.py
    res
    search
    static
    ui
