### CS122, Winter 2018: Course search engine: search
###
### Lucia Delgado, Juliana Aguilar

from math import radians, cos, sin, asin, sqrt
import sqlite3
import os


# Use this filename for the database
DATA_DIR = os.path.dirname(__file__)
DATABASE_FILENAME = os.path.join(DATA_DIR, 'course_information.sqlite3')


def find_courses(args_from_ui):
  '''
  Takes a dictionary containing search criteria and returns courses
  that match the criteria.  The dictionary will contain some of the
  following fields:

    - dept a string
    - day is array with variable number of elements
         -> ["'MWF'", "'TR'", etc.]
    - time_start is an integer in the range 0-2359
    - time_end is an integer an integer in the range 0-2359
    - enroll is an integer
    - walking_time is an integer
    - building ia string
    - terms is a string: "quantum plato"]

  Returns a pair: list of attribute names in order and a list
  containing query results.
  '''

  #0. PRE
  d = args_from_ui

  if d =={}:
    return ([],[])

  #1. CONECTION AND CURSOR
  connect_courses = sqlite3.connect("course_information.sqlite3")
  c = connect_courses.cursor()

  #2. SELECT (list of output vars)

  #Get list of output variables in order
  output_var_list = output_var(d)

  # Gen a string of output variables
  var_string = ""
  for i in output_var_list:
    var_string = var_string  + i + ", "
  var_string = var_string[:-2]

  #3. WHERE (query conditions)
  query = "" 

  for var in ["dept"]:
    if d.get(var) != None:
      query = query + " " + var + " = \"" + str(d[var]) + "\" and "


  for var in ["time_start"]:
    if d.get(var) != None:
      query = query + " " + var + " >= " + str(d[var]) + " and "  


  for var in ["time_end"]:
    if d.get(var) != None:
      query = query + " " + var + " <= " + str(d[var]) + " and " 

  if d.get("enroll_lower") != None:
    query = query + " " + "enrollment" + " >= " + str(d["enroll_lower"]) + " and "
  if d.get("enroll_upper") != None:
    query = query + " " + "enrollment" + " <= " + str(d["enroll_upper"]) + " and "

  if d.get("day") != None:
    day_list = d.get("day")
    
    if len(day_list) == 0:
      day_query = ""
    if len(day_list) == 1:
      day_query = "day = " + "'" + str(day_list[0]) + "'"
    else:
      for i in day_list:
        day_query = "("
        day_query = day_query + "day = " + '"' + i + '"' + " or " 

      day_query = day_query[:-3] + ")"
    
    query = query + day_query + " and "

  terms_query = ""
  word_search = ""

  if len(query) > 0:
    query = "WHERE " + query[:-4]

  if d.get("terms") != None:
    terms_string = d.get("terms")
    terms_list = terms_string.split()

    if len(terms_list) == 0:
      terms_query = ""
   
    if len(terms_list) == 1:
      terms_query = "word = " + "'" + str(terms_list[0]) + "'"

    else:
      word_str = "("
      for i in terms_list:
        word_str += "'" + i + "', "  
      word_str = word_str[:-2] + ")"
      terms_query = "WHERE word IN " + word_str

      word_search = " GROUP BY course_id HAVING count(*) = " + str(len(terms_list))


  #Walking time filter
  connect_courses.create_function("time_between", 4, compute_time_between) 

  if d.get("building") == None:
    walking_time_filter = "SELECT building_code as building FROM gps"
  else:
    walking_time_filter = "SELECT building_code as building, walking_time FROM (SELECT a.building_code," \
    "time_between(a.lon, a.lat, b.lon, b.lat) AS walking_time FROM gps AS a " \
    "JOIN (SELECT * FROM gps WHERE building_code = \"" + d["building"] + "\") AS b)"
    if d.get("walking_time")!=None: 
      walking_time_filter += " WHERE walking_time <=" + str(d["walking_time"])
    else:
      walking_time_filter += " WHERE building_code = \"" + d["building"] + "\""


  #4. GENERATE A QUERY THAT JOINS OF ALL BASES = masterdb

  #THIS QUERY OBTAINS COURSES WITH THE WORDS WE WANT
  sub = "SELECT course_id FROM catalog_index " +\
  terms_query + " " + word_search 

  #THEN WE ADD ALL THE QUERIES
  master_s2 =  "SELECT DISTINCT " + var_string + \
  " FROM ( " + sub + ") " \
  "as filtered JOIN courses JOIN (" \
  "SELECT * "  \
  "FROM (" + walking_time_filter + ")  as wt JOIN ("  \
  "SELECT * " \
  "FROM sections JOIN meeting_patterns " \
  "ON sections.meeting_pattern_id = meeting_patterns.meeting_pattern_id) " \
  "AS sect_meet " \
  "ON wt.building = sect_meet.building_code) " \
  "AS sect_gps_meet " \
  "ON filtered.course_id = courses.course_id = sect_gps_meet.course_id " \
  + query  + " COLLATE NOCASE;"

  #EXECUTE AND SHOW RESULTS
  master = c.execute(master_s2)
  output = master.fetchall()

  #Close Connection
  connect_courses.close()

  # replace with a list of the attribute names in order and a list
  # of query results.
  return (output_var_list, output)




def output_var(d):
  '''
  This function takes a dictionary indicating the user's query
  and returns a list of variables that should be included in the 
  output
  Input: dictionary
  Returns: list of strings
  '''
  output = []
    
  if d.get("terms") != None:
    output = output + ["dept", "course_num", "title"]

  if d.get("dept") != None:
    output = output + ["dept", "course_num", "title"]
  
  if d.get("day") != None:
    output = output + ["dept", "course_num", 
    "section_num", "day", "time_start", "time_end"
    "title"]

  if d.get("time_start") != None:
    output = output + ["dept", "course_num", 
    "section_num", "day", "time_start", "time_end"
    ]

  if d.get("time_end") != None:
    output = output + ["dept", "course_num", 
    "section_num", "day", "time_start", "time_end"
    ]
  
  if d.get("walking_time") != None:
    output = output + ["dept", "course_num", 
    "section_num", "day", "time_start", "time_end",
    "building", "walking_time"
    ]

  if d.get("building") != None:
    output = output + ["dept", "course_num", 
    "section_num", "day", "time_start", "time_end",
    "building", "walking_time"
    ]

  if d.get("enroll_lower") != None:
    output = output + ["dept", "course_num", 
    "section_num", "day", "time_start", "time_end",
    "enrollment"
    ]

  if d.get("enroll_upper") != None:
    output = output + ["dept", "course_num", 
    "section_num", "day", "time_start", "time_end",
    "enrollment"
    ]

  var_list = ["dept", "course_num", 
    "section_num", "day", "time_start", "time_end",
    "building", "walking_time",
    "enrollment", "title"]

  final_list = ["dept", "course_num", 
    "section_num", "day", "time_start", "time_end",
    "building", "walking_time",
    "enrollment", "title"]

  for i in var_list:
    if i not in output:
      final_list.remove(i)

  return final_list


########### auxiliary functions #################
########### do not change this code #############

def compute_time_between(lon1, lat1, lon2, lat2):
    '''
    Converts the output of the haversine formula to walking time in minutes
    '''
    meters = haversine(lon1, lat1, lon2, lat2)

    # adjusted downwards to account for manhattan distance
    walk_speed_m_per_sec = 1.1
    mins = meters / (walk_speed_m_per_sec * 60)

    return mins


def haversine(lon1, lat1, lon2, lat2):
    '''
    Calculate the circle distance between two points
    on the earth (specified in decimal degrees)
    '''
    # convert decimal degrees to radians
    lon1, lat1, lon2, lat2 = map(radians, [lon1, lat1, lon2, lat2])

    # haversine formula
    dlon = lon2 - lon1
    dlat = lat2 - lat1
    a = sin(dlat / 2)**2 + cos(lat1) * cos(lat2) * sin(dlon / 2)**2
    c = 2 * asin(sqrt(a))

    # 6367 km is the radius of the Earth
    km = 6367 * c
    m = km * 1000
    return m


def get_header(cursor):
    '''
    Given a cursor object, returns the appropriate header (column names)
    '''
    desc = cursor.description
    header = ()

    for i in desc:
        header = header + (clean_header(i[0]),)

    return list(header)


def clean_header(s):
    '''
    Removes table name from header
    '''
    for i, _ in enumerate(s):
        if s[i] == ".":
            s = s[i + 1:]
            break

    return s


########### some sample inputs #################

EXAMPLE_0 = {"time_start": 930,
             "time_end": 1500,
             "day": ["MWF"]}

EXAMPLE_1 = {"dept": "CMSC",
             "day": ["MWF", "TR"],
             "time_start": 1030,
             "time_end": 1500,
             "enroll_lower": 20,
             "terms": "computer science"}
