# CS121 Lab 3: Functions

import math

# Your distance function goes here 

# Your perimeter function goes here 

def go():
    '''
    Write a small amount of code to verify that your functions work

    Verify that the distance between the points (0, 1) and (1, 0) is
    close to math.sqrt(2)

    After that is done, verify that the triangle 
    with vertices at (0, 0), (0, 1), (1, 0) has 
    a perimeter 2 + math.sqrt(2)
    '''

    # replace the pass with code that calls your functions
    # and prints the results
    pass

if __name__ == "__main__":
    go()
    
                

