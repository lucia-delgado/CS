CS122 Autocomplete Assignment

english_dictionary.py       -- you will complete the EnglishDictionary and
                               TrieNode classes in this file.
english_dictionary_list.py  -- a list implementation of the EnglishDictionary class.
autocorrect_shell.py        -- user-interface implementation.
test_english_dictionary.py  -- pytest code for testing your implementation.
web2                        -- a copy of the words from the 1934 edition of
                               Merriam-Webster's Dictionary.
five                        -- a simple list of words with only the five words
                               shown in the example diagram in the assignment writeup

README.txt                  -- this file
