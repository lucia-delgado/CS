# CS121 Lab 3: Function


# Write functions any, add_lists, and add_one


def go():
    '''
    Write code to verify that your functions work as expected here
    Try to think of a few good examples to test your work.
    '''

    # replace the pass with test code for your functions
    pass


if __name__ == "__main__":
    go()

