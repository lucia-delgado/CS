CS 122 W'17: Course Search Engine

README.txt: this file

crawler.py: Skeleton for the catalog crawler/indexer. You will modify
  this file

course_map.json: JSON file that contains a dictionary that maps course
  codes (for example, "CMSC 12200") to unique identifiers.

util.py: utility functions for dealing with URLs.


