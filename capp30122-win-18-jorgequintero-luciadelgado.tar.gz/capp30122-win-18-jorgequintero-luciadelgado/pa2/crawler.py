# CS122: Course Search Engine Part 1
#
# Your name(s)
#   Lucia Delgado
#   Jorge Quintero
#

import re
import util
import bs4
import queue
import json
import sys
import csv

INDEX_IGNORE = set(['a', 'also', 'an', 'and', 'are', 'as', 'at', 'be',
                    'but', 'by', 'course', 'for', 'from', 'how', 'i',
                    'ii', 'iii', 'in', 'include', 'is', 'not', 'of',
                    'on', 'or', 's', 'sequence', 'so', 'social', 'students',
                    'such', 'that', 'the', 'their', 'this', 'through', 'to',
                    'topics', 'units', 'we', 'were', 'which', 'will', 'with',
                    'yet'])


### YOUR FUNCTIONS HERE

def build_soup(website):

    sitio = util.get_request(website)
    siitio = util.read_request(sitio)
    soup = bs4.BeautifulSoup(siitio, "html5lib") 

    return soup

def soup_to_url(soup, website):

    link_list = []

    for link in soup.find_all('a'):
        url_only = link.get('href')
        clean_link = util.remove_fragment(url_only)
        absolute_link = util.convert_if_relative_url(website,clean_link)
        if util.is_url_ok_to_follow(absolute_link,limiting_domain) == True:
            link_list.append(absolute_link)


    return(link_list)


def code_to_id(soup, course_map_filename):


    for div in soup.find_all('div', class_="courseblock main"):
        children = div.findChildren()
        for child in children:
            print (child)

    '''
    for div in soup.find_all('div', class_="courseblock main"):
        print(div.get('p')
        for course in soup.find_all('p', class_="courseblocktitle"):
            print(course)



        url_only = link.get('href')
        clean_link = util.remove_fragment(url_only)
        absolute_link = util.convert_if_relative_url(website,clean_link)
        if util.is_url_ok_to_follow(absolute_link,limiting_domain) == True:
            link_list.append(absolute_link)
    '''
def div_to_title (children):
    """
    Input: div
    Returns: course code
    """

    #See if it is a sub sequence
    


def soup_to_data(soup):
    pass
    #soup.find_all('div', class_="courseblock main" or class_="courseblock subsequence")

 

def go(num_pages_to_crawl, course_map_filename, index_filename):
    '''
    Crawl the college catalog and generates a CSV file with an index.

    Inputs:
        num_pages_to_crawl: the number of pages to process during the crawl
        course_map_filename: the name of a JSON file that contains the mapping
          course codes to course identifiers
        index_filename: the name for the CSV of the index.

    Outputs:
        CSV file of the index index.
    '''

    starting_url = ("http://www.classes.cs.uchicago.edu/archive/2015/winter"
                    "/12200-1/new.collegecatalog.uchicago.edu/index.html")
    limiting_domain = "classes.cs.uchicago.edu"

    # YOUR CODE HERE


if __name__ == "__main__":
    usage = "python3 crawl.py <number of pages to crawl>"
    args_len = len(sys.argv)
    course_map_filename = "course_map.json"
    index_filename = "catalog_index.csv"
    if args_len == 1:
        num_pages_to_crawl = 1000
    elif args_len == 2:
        try:
            num_pages_to_crawl = int(sys.argv[1])
        except ValueError:
            print(usage)
            sys.exit(0)
    else:
        print(usage)
        sys.exit(0)

    go(num_pages_to_crawl, course_map_filename, index_filename)
